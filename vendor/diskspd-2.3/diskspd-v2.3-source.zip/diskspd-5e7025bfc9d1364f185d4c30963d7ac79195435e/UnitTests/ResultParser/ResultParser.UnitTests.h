/*

DISKSPD

Copyright(c) Microsoft Corporation
All rights reserved.

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/

#pragma once
#include "WexTestClass.h"

namespace UnitTests
{
    BEGIN_MODULE()
        MODULE_PROPERTY(L"Feature", L"ResultParser")
    END_MODULE()

    class ResultParserUnitTests : public WEX::TestClass<ResultParserUnitTests>
    {
    public:
        TEST_CLASS(ResultParserUnitTests);
        TEST_METHOD(Test_ParseResults);
        TEST_METHOD(Test_ParseProfile);
        TEST_METHOD(Test_PrintTarget);
        TEST_METHOD(Test_PrintTargetDistributionPct);
        TEST_METHOD(Test_PrintTargetDistributionAbs);
        TEST_METHOD(Test_PrintEffectiveDistributionPct);
        TEST_METHOD(Test_PrintEffectiveDistributionAbs);
        TEST_METHOD(Test_PrintProfileBufferSeparationSystemDefault);
        TEST_METHOD(Test_PrintProfileBufferSeparation8KPage128BLine);
        TEST_METHOD(Test_PrintResultsBufferSeparation8KPage128BLine);
        TEST_METHOD(Test_PrintWaitStatsNoThrottleNoLookaside);
        TEST_METHOD(Test_PrintWaitStatsWithThrottle);
        TEST_METHOD(Test_PrintWaitStatsWithLookaside);
        TEST_METHOD(Test_PrintAffinityPolicy);
    };
}

